import './font.css'

console.log('optimization')
