console.log('test public resource')
