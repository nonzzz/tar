import { result } from './code'
import './style.css'

console.log(result)
