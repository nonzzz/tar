# Vite-plugin-compression2-starter

## Step

```bash
$ yarn // install dependices

$ yarn build // packing static resources

$ yarn preview // start a local server to preivew the result.
```

## F & Q

> How to use with others web server?

- This example is very simple usage. If you're using [NGINX](https://nginx.org/en/) you can refer [document](https://nginx.org/en/docs/http/ngx_http_gzip_module.html)
