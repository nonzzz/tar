console.log('vite-plugin-compression2')
