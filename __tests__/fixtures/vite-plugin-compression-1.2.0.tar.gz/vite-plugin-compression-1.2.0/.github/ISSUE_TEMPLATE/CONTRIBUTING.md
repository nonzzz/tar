## Vite-Compression-plugin GUide

### Ready to start

We welcome everyone to join the construction of the project. As a pre requirement. You need know
Git, if you don't know it. There is a basic operation of git refer to [GitHub's help documentation](https://help.github.com/en/github/using-git).

1. [Fork this repository](https://help.github.com/en/github/getting-started-with-github/fork-a-repo) to your own account and then clone it.
2. Create a new branch for your changes: `git checkout -b {BRANCH_NAME}`.
3. Install a package management tools [Yarn](https://classic.yarnpkg.com/en/docs/install#mac-stable)
4. Install project dependices.
5. Change the code you want.

At any time, you think it's ok, you can start the following steps to submit your amazing works:

1. Run `yarn test` check the result.

### Q & A

> What should i consider when testing.

- Make sure branches are covered as much as possible.
