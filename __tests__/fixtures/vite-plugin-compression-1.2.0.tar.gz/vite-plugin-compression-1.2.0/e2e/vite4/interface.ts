export type Vite4Instance = typeof import('vite')
