export type Vite5Instance = typeof import('vite')
