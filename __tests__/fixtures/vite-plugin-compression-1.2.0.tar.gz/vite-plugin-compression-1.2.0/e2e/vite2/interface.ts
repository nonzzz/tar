export type Vite2Instance = typeof import('vite')
