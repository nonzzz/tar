export type Vite3Instance = typeof import('vite')
